#pragma once

#include "goblin_cannon/rf_stream.hpp"

#include <algorithm>
#include <cmath>
#include <numbers>
#include <vector>

namespace goblin_cannon::detail {

// Causal, symbol-spaced decision-feedback equalizer. The current sample is the
// main cursor: no extra lookahead or payload block buffering is needed. NLMS
// trains on known symbols, then tracks with pilots and confident decisions.
class RfEqualizer {
public:
  explicit RfEqualizer(const RfStreamConfig& config)
      : carrier_enabled_(config.carrier_correction),
        adaptive_(config.adaptive_equalization),
        forward_(validated_forward_taps(config)),
        feedback_(config.equalizer_feedback_taps),
        samples_(forward_.size()), decisions_(feedback_.size()) {
    reset();
  }

  void reset() {
    std::fill(forward_.begin(), forward_.end(), Complex{});
    std::fill(feedback_.begin(), feedback_.end(), Complex{});
    forward_.front() = {1.0F, 0.0F};
    restart_training_pass();
  }

  void clear_history() {
    std::fill(samples_.begin(), samples_.end(), Complex{});
    std::fill(decisions_.begin(), decisions_.end(), Complex{});
    history_symbols_ = 0;
  }

  void restart_training_pass() {
    clear_history();
    phase_ = 0.0;
    frequency_ = 0.0;
  }

  [[nodiscard]] std::size_t memory_symbols() const {
    return std::max(samples_.size() - 1U, decisions_.size());
  }

  void advance_phase(double symbols) {
    phase_ = std::remainder(phase_ + frequency_ * symbols, 2.0 * std::numbers::pi);
  }

  Complex filter(Complex sample) {
    advance_phase(1.0);
    if (carrier_enabled_) {
      sample *= std::polar(1.0F, static_cast<float>(-phase_));
    }
    std::move_backward(samples_.begin(), samples_.end() - 1, samples_.end());
    samples_.front() = sample;
    Complex output{};
    for (std::size_t i = 0; i < forward_.size(); ++i) {
      output += forward_[i] * samples_[i];
    }
    for (std::size_t i = 0; i < feedback_.size(); ++i) {
      output += feedback_[i] * decisions_[i];
    }
    return output;
  }

  // Always record a decision for causal feedback. Low confidence freezes both
  // loops rather than teaching the equalizer errors during a fade.
  void update(Complex desired, Complex observed, float step, bool reliable) {
    if (reliable && history_symbols_ >= memory_symbols() &&
        std::isfinite(observed.real()) && std::isfinite(observed.imag())) {
      const auto error = desired - observed;
      if (carrier_enabled_ && std::norm(desired) > 1.0e-6F && std::norm(observed) > 1.0e-6F) {
        const auto phase_error = std::clamp(static_cast<double>(std::arg(observed * std::conj(desired))), -0.5, 0.5);
        frequency_ = std::clamp(frequency_ + 0.0005 * phase_error, -0.05, 0.05);
        phase_ = std::remainder(phase_ + 0.08 * phase_error, 2.0 * std::numbers::pi);
      }
      if (adaptive_ && std::norm(error) < 4.0F) {
        float energy = 1.0e-4F;
        for (const auto value : samples_) {
          energy += std::norm(value);
        }
        for (const auto value : decisions_) {
          energy += std::norm(value);
        }
        const auto correction = error * (step / energy);
        for (std::size_t i = 0; i < forward_.size(); ++i) {
          forward_[i] += correction * std::conj(samples_[i]);
        }
        for (std::size_t i = 0; i < feedback_.size(); ++i) {
          feedback_[i] += correction * std::conj(decisions_[i]);
        }
      }
    }
    if (!decisions_.empty()) {
      std::move_backward(decisions_.begin(), decisions_.end() - 1, decisions_.end());
      decisions_.front() = desired;
    }
    ++history_symbols_;
  }

private:
  static std::size_t validated_forward_taps(const RfStreamConfig& config) {
    validate(config);
    return config.equalizer_feedforward_taps;
  }

  bool carrier_enabled_;
  bool adaptive_;
  std::vector<Complex> forward_;
  std::vector<Complex> feedback_;
  std::vector<Complex> samples_;
  std::vector<Complex> decisions_;
  std::size_t history_symbols_ = 0;
  double phase_ = 0.0;
  double frequency_ = 0.0;
};

} // namespace goblin_cannon::detail
