# Questions from the simulated channel audit

These are design/acceptance questions and recorded decisions from Adam.
The original audit preserved production behavior. Adam subsequently authorized
fix #1 (24 kHz clean-channel reception); follow-up results identify the tested
source snapshot separately from the original audit.

## Carrier boundary in the simulated channel

1. Earlier work added an acquisition frequency estimator, sample NCO, and a
   residual frequency/phase PLL. The new brief assigns this work to the radio.
   Adam confirmed testing with `carrier_correction=false` through the existing
   API. That disables the phase PLL too; the complex adaptive equalizer remains
   enabled.
   Should the estimator/tracker eventually be removed, or should phase-only
   correction receive its own switch? No production change is made here.
2. Fixed with Adam's authorization: the decoder rounded the matched filter's
   last required sample up instead of down. At 2.5 samples/symbol this withheld
   the last training/header symbol indefinitely. The readiness check now uses
   the filter's actual inclusive boundary. New strict regressions cover complete
   finite blocks and both bandwidth profiles with QPSK, 16-QAM and 64-QAM.
   Original result files retain their historical failures and source hashes.

## Waveform and channel assumptions in the simulated channel

3. The code supplies ten constellations, RRC shaping, a custom QPSK startup/header,
   punctured convolutional coding, and no interleaver. It does not implement the
   Appendix D waveform-number/rate/interleaver combinations. Its 10 kHz profile
   is not a bandwidth listed in Table D-I. Which standard configurations should
   eventually be considered directly comparable? Current tables identify actual
   library modulation/FEC combinations and do not assert MIL-STD conformance.
4. All nine requested preset pairs are verified. F.1487 includes an inconsistent
   cross-reference equating low-latitude moderate (2 ms / 1.5 Hz) with the former
   poor channel; F.520-2 itself says **2 ms / 1 Hz**. The `ccir_poor` preset follows
   F.520-2. The high-latitude values are 1/.5, 3/10, and 7/30 in ms/Hz.
5. F.1487 describes applicability up to approximately 12 kHz and warns about
   extrapolation to wider channels. Is its two-path model an acceptable screening
   model for the 24 kHz profile pending measured channel statistics?
6. A1 declares 10 simulated seconds per grid point. F.1487's statistical-duration
   recommendation is `max(3000/spread, 100/(BER*data_rate))` seconds; at 0.1 Hz the
   first term alone is 30,000 seconds. The short full-tier matrix cannot establish
   those operating limits. Should a separate standards-duration campaign be
   scheduled? C1 reports empirical crossings separately from established limits.
7. Is SNR to remain per complex baseband sample, or should future acceptance
   profiles use a specified receiver noise bandwidth? The existing simulator's
   convention is retained and cannot be compared numerically to 3 kHz SNR tables
   without the appropriate bandwidth convention.

## Data-path assumptions in the simulated channel

8. AES-128-CTR is followed by a CRC integrity check, not an AEAD tag. Authentication
   failures cannot be counted, and CRC is not substituted for authentication.
   What AEAD/replay/nonce-lifetime contract is intended? Restarting with an
   unchanged key and default counter repeats the CTR keystream. The caller owns
   counter selection; the harness does not supply an invented nonce allocator.
9. The auction ranks bids per wire byte and retains one pending winner globally.
   It does not retain the newest update per instrument and does not preempt an
   already queued winner. Strict priority, unconditional starvation freedom, and
   source coalescing are different requirements. Which auction semantics should
   supersede the current policy?
10. Application messages do not carry frame sequence numbers. Duplicate/stale
    suppression, sequence wrap, and explicit downstream FEC gaps are not exposed.
    What message identifier/key and gap notification should these tests target?
11. The audio API carries sample arrays without block sequence or gap metadata.
    Should underrun/overrun events be added to that interface in a later change?
12. The fiber link is a control path. D5 is conditional and currently unavailable;
    no parallel fiber data-delivery arbiter is invented.
13. Mode changes occur by matching configuration and restarting epochs over gRPC.
    There is no mid-stream interleaver change. C5 is conditional and unavailable.
14. RF frames are fixed symbol-count bookkeeping; application messages cross
    those boundaries and carry CRC trailers. Empty RF frames are rejected and
    application message size has no declared maximum. What empty/maximum cases
    should C4 use beyond the generated valid-message tests?

## Metrics and assets for the simulated channel

15. B5 asks for measured host latency while E1 asks for identical seeded metrics.
    CPU/OS wall times cannot meet byte determinism. Canonical records contain
    sample-clock source-to-sink latency, including startup and configured audio
    buffering. B5 additionally runs a paced host loopback through the real
    auction, framing, FEC, crypto and modem; CPU/OS timings are stored separately
    in `.host.json`. Adam requested repeating B5 on the quieter `naamah` host;
    the comparison preserves the original `avx10` observations. Physical audio
    drivers and network sockets require an integration fixture beyond the
    simulated buffer model.
16. Should the 2.1 ms allowance include initial epoch acquisition, serialization,
    and FEC traceback? The report currently includes their sample-clock residence
    and labels that value a lower bound, not a CPU execution-time measurement.
17. The STAC detailed audit attachment requires login. Its public summary and
    presentation do not define all adjustment/standby rules. Please supply the
    audit methodology to establish exact E2 comparability. The report gives local
    metric definitions and leaves exact STAC-adjusted values null.
18. This is a single-carrier modem. There are no edge subcarriers, and individual
    symbols cannot be assigned to a frequency edge. B3 reports total BER under
    the specified filter instead of inventing an edge-symbol BER.
19. E4 needs receive-only recordings with frequency, UTC capture time, location,
    sample format/rate, source/provenance, and use permission. No recording was
    supplied; Adam confirmed that none are available. E4 remains unavailable
    pending recordings; synthetic Gaussian noise is never labeled recorded-band
    noise.
20. Adam confirmed leaving the margins in `results/SUMMARY.md` as `THRESHOLD_TBD`:
    residual-offset BER, acquisition deadline, recovery frames, pattern comparison,
    newest-message delay, freshness agreement, starvation delay, rotation loss, and soak
    memory/queue/latency bounds. Measurements and proposed values are retained
    for later review; proposed values are not enforced.
21. The complete quick tier exceeds 120 seconds on the four-vCPU `avx10` host.
    All requested ten-minute traces and paired drift controls are retained.
    Should CI receive more CPU capacity, or should the tier budget be revised?
22. The matrix holds the existing equalizer configuration at three feedforward
    and four feedback taps. Should a later characterization sweep use longer
    tap spans configured through the fiber control path? The current findings
    describe this fixed configuration and do not establish route feasibility.
23. D2 retained both 0–30 dB grids and added eight SNR refinements per target.
    The closest measured RF survival fractions were 22.3%, 71.7%, and 71.8%
    for targets of 30%, 50%, and 80%. Should a later calibration include more
    channel families or controlled dropout patterns? Agreement with independent
    direct erasures also needs a contract for burst structure, not just survival.

## Primary sources for the simulated channel

- [ITU-R F.1487](https://www.itu.int/dms_pubrec/itu-r/rec/f/R-REC-F.1487-0-200005-I!!PDF-E.pdf), Annex 1 (Gaussian power spectrum, spread = 2σ), Annex 3 (presets and test length).
- [ITU-R F.520-2](https://www.itu.int/dms_pubrec/itu-r/rec/f/R-REC-F.520-2-199203-W!!PDF-E.pdf), Annex 1 §2.2 (good/moderate/poor).
- [MIL-STD-188-110C, DLA copy](https://quicksearch.dla.mil/Transient/D1A6E2FA29A74374ABCEEDAF36DDA384.pdf), Appendix D Tables D-I/D-II (bandwidth, symbol rate and waveform mapping). DLA transient links can expire; use ASSIST for a fresh copy.
- [STAC audit landing page](https://docs.stacresearch.com/RFT230516) (attachment requires login), [public summary](https://docs.stacresearch.com/news/RFT230516), and [STAC presentation](https://docs.stacresearch.com/system/files/resource/files/STAC-Summit-19-October-2023-STAC-Network.pdf).
