"""Declared simulated channel matrix. No adaptive reductions of grids/durations."""
from __future__ import annotations

from dataclasses import dataclass, field
from itertools import product
from pathlib import Path

SEED = 0x71A001
SNR_GRID = tuple(range(0, 31, 2))
MODULATIONS = ("qpsk", "8psk", "16qam", "64qam", "256qam", "1024qam",
               "16qci", "64qci", "256qci", "1024qci")
BITS = dict(zip(MODULATIONS, (2, 3, 4, 6, 8, 10, 4, 6, 8, 10)))
RATES = ("1/2", "2/3", "3/4")
PROFILES = (10000, 24000)
# Verified against F.520-2 Annex 1 and F.1487 Annex 3. Spread is 2*sigma.
PRESETS = {
    "ccir_good": (0.5, 0.1), "ccir_poor": (2.0, 1.0),
    "mid_lat_quiet": (0.5, 0.1), "mid_lat_moderate": (1.0, 0.5),
    "mid_lat_disturbed": (2.0, 1.0), "high_lat_quiet": (1.0, 0.5),
    "high_lat_moderate": (3.0, 10.0), "high_lat_disturbed": (7.0, 30.0),
    "low_lat_disturbed": (6.0, 10.0),
}
STAGE_ORDER = ("channel", "interferers", "impulsive_noise", "dropout", "agc",
               "clipping", "band_limiting", "sample_rate_mismatch",
               "residual_offset_drift", "audio_jitter")
# None is serialized as JSON null and converted to +infinity only for the probe.
DEFAULTS = dict(
    mode="rf", modulation="qpsk", bandwidth_hz=24000, sample_rate_hz=48000,
    duration_s=2.0, chunk_samples=256, frame_symbols=64, training_symbols=64,
    fec="none", carrier_correction=0, seed=SEED, require_avx512=1,
    channel_model="null", snr_db=None, delay_spread_ms=0.0, doppler_spread_hz=1.0,
    path0_db=0.0, path1_db=0.0, pure_noise=0, phase_rad=0.0,
    cw_hz=0.0, cw_sir_db=None, data_sir_db=None, interferer_start_s=0.0,
    impulse_ms=0.0, impulses_per_second=0.0, impulse_above_noise_db=0.0,
    dropout_start_s=0.0, dropout_duration_s=0.0,
    agc_step_db=0.0, agc_start_s=0.1, agc_attack_ms=1.0, agc_decay_ms=100.0,
    clip_amplitude=None, soft_clip=0, calibrate_clip=0,
    filter_bandwidth_hz=0.0, group_delay_ripple_ms=0.0,
    notch_center_hz=0.0, notch_width_hz=0.0, notch_depth_db=0.0,
    clock_ppm=0.0, residual_offset_hz=0.0, residual_drift_hz_per_second=0.0,
    sample_slip_index=-1, sample_slip=0, pattern="random",
    message_interval_s=0.01, jitter_ms=0.0, audio_event="", audio_event_s=0.5,
    overload=1.0, capacity_messages_per_s=100.0, instruments=16, flood=0,
    semantics="duplicate",
    direct_survival=1.0, soak=0, noise_file="",host_timing=0,auction_intake=0,source_load_factor=0,
)
OPEN_THRESHOLDS = {
    "A4.ber_delta": ("0 absolute excess BER in the noise-free regression; select a confidence interval for noisy runs", "No radio residual-offset budget or BER margin is specified."),
    "C2.acquisition_seconds": ("one complete preamble/training/header plus one audio block", "The configured startup lengths give a measurable lower bound; approval needed."),
    "C3.recovery_frames": ("2 frames after a new valid epoch preamble", "The current stream needs an epoch preamble to reacquire; a deadline without one is undefined."),
    "C4.pattern_ber_margin": ("a paired confidence interval, with its significance level selected by Adam", "Equal finite-sample BER is not a statistical scrambler test."),
    "D1.newest_latency_ms": ("one frame duration + 2.1 ms, as proposed in the brief", "Needs agreement on whether serialization, FEC lookahead and startup are included."),
    "D2.freshness_agreement_ms": ("compare paired freshness distributions; select a quantile margin", "Equal survival fractions do not imply equal burst structure."),
    "D2.target_survival_margin": ("select a confidence interval for channel calibration; direct erasures round to the nearest whole frame", "A finite SNR grid cannot guarantee exactly 30%, 50%, or 80% channel survival."),
    "D3.instrument_delay_ms": ("one frame duration + 2.1 ms", "Strict bid priority and starvation freedom can conflict under sustained overload."),
    "D6.rotation_loss_frames": ("one epoch startup plus the in-flight frame", "There is no coordinated rotation protocol to measure yet."),
    "E3.memory_growth_bytes": ("zero steady growth after warmup; choose an allocator/RSS allowance", "Host RSS varies and includes harness allocations."),
    "E3.queue_depth": ("configured ring capacity plus one pending auction bid", "Must distinguish queue capacity from newest-message freshness."),
    "E3.latency_change": ("a paired percentile tolerance chosen from baseline variability", "Exact equality across different fading realizations is not a usable acceptance rule."),
}

@dataclass
class Case:
    name: str
    group: str
    kind: str
    tier: str
    parameters: dict
    checks: tuple[str, ...] = ()
    thresholds: tuple[str, ...] = ()
    unavailable: str | None = None
    notes: list[str] = field(default_factory=list)


def case(group, name, kind, tier, *, checks=(), thresholds=(), unavailable=None, notes=(), **kwargs):
    parameters = DEFAULTS | kwargs
    return Case(f"{group}_{name}", group, kind, tier, parameters,
                tuple(checks), tuple(thresholds), unavailable, list(notes))


def preset(name):
    delay, doppler = PRESETS[name]
    return dict(channel_model="watterson", delay_spread_ms=delay, doppler_spread_hz=doppler)


def matrix():
    cases = []
    add = cases.append
    # Ten seconds per point is a declared screening duration. It is not the
    # much longer F.1487 statistical test length. C1 reports censored bounds.
    for bw, mod, fec, channel, snr in product(PROFILES, MODULATIONS, RATES, PRESETS, SNR_GRID):
        add(case("A1", f"{bw}_{mod}_{fec.replace('/', '-')}_{channel}_{snr}dB", "characterize", "full",
                 bandwidth_hz=bw, modulation=mod, fec=fec, snr_db=snr,
                 duration_s=10, **preset(channel),
                 notes=["10 s screening trace; not F.1487 Annex 3 statistical-duration compliance."]))
    for delay, gain, mod in product((0.5, 1, 2, 3, 5, 7), (0, -6), ("qpsk", "16qam", "64qam")):
        add(case("A2", f"{mod}_{delay}ms_{gain}dB", "characterize", "full", modulation=mod,
                 channel_model="watterson", delay_spread_ms=delay, doppler_spread_hz=1,
                 path1_db=gain, snr_db=30, duration_s=10))
    for spread, mod in product((0.1, 0.5, 1, 3, 10, 30), ("qpsk", "16qam", "64qam")):
        add(case("A3", f"{mod}_{spread}Hz", "characterize", "full", modulation=mod,
                 channel_model="watterson", delay_spread_ms=2, doppler_spread_hz=spread, snr_db=30, duration_s=10))
    for bw, mod in product(PROFILES, ("qpsk", "16qam", "64qam")):
        for offset in (0, -1, 1, -3, 3, -5, 5):
            add(case("A4", f"{bw}_{mod}_offset_{offset}", "assert", "quick", bandwidth_hz=bw,
                     modulation=mod, residual_offset_hz=offset, duration_s=10,
                     checks=("sync_held",), thresholds=("A4.ber_delta",)))
        add(case("A4", f"{bw}_{mod}_drift_10min", "assert", "quick", bandwidth_hz=bw,
                 modulation=mod, residual_drift_hz_per_second=1/60, duration_s=600, chunk_samples=2048,
                 checks=("sync_held",), thresholds=("A4.ber_delta",)))
        for ppm in (-200, -50, 50, 200):
            add(case("A4", f"{bw}_{mod}_{ppm}ppm_10min", "assert" if abs(ppm)==50 else "characterize", "quick",
                     bandwidth_hz=bw, modulation=mod, clock_ppm=ppm, duration_s=600, chunk_samples=2048,
                     checks=("no_frame_boundary_loss",) if abs(ppm)==50 else ()))
    for width, depth, center, mod in product((1000, 2000, 3000, 4000), (20, 30, 40), (0, 6000, 11000), ("qpsk", "16qam", "64qam")):
        add(case("A5", f"{mod}_{width}_{depth}_{center}", "characterize", "full", modulation=mod,
                 notch_width_hz=width, notch_depth_db=depth, notch_center_hz=center, snr_db=30, duration_s=10))
    for length, frequency, height in product((0.1, 0.5, 1, 5), (1, 10, 100), (20, 30, 40)):
        add(case("A6", f"{length}ms_{frequency}Hz_{height}dB", "characterize", "full", **preset("mid_lat_moderate"),
                 impulse_ms=length, impulses_per_second=frequency, impulse_above_noise_db=height, snr_db=30, duration_s=10))
    for hz, sir, mod in product(range(-12000, 12001, 2000), (20, 10, 0, -10), ("qpsk", "16qam", "64qam")):
        add(case("A7", f"{mod}_{hz}Hz_{sir}dB", "characterize", "full", modulation=mod,
                 cw_hz=hz, cw_sir_db=sir, snr_db=30, duration_s=10))
    for sir in (10, 0, -10):
        add(case("A8", f"cochannel_{sir}dB", "assert", "full", mode="messages", fec="1/2", chunk_samples=48,
                 data_sir_db=sir, interferer_start_s=0.505, duration_s=10,
                 checks=("authenticated_delivery", "no_corrupt_messages")))
    for loss in (2, 30, 300):
        add(case("A9", f"dropout_{loss}s", "assert", "full", mode="messages", fec="1/2", chunk_samples=48,
                 **preset("high_lat_moderate"), snr_db=30, dropout_start_s=2, dropout_duration_s=loss,
                 duration_s=loss+12, checks=("no_stale_messages",),
                 notes=["Continuous transmitter; no fabricated recovery preamble or receiver reset."]))
    for bw, db, attack, decay, mod in product(PROFILES, (-20, 20), (1, 10), (100, 1000), ("qpsk", "16qam", "64qam")):
        add(case("B1", f"{bw}_{mod}_{db}dB_{attack}_{decay}", "assert", "quick", bandwidth_hz=bw, modulation=mod,
                 agc_step_db=db, agc_attack_ms=attack, agc_decay_ms=decay, checks=("sync_held",)))
    for bw, mod, soft, top in product(PROFILES, ("qpsk", "16qam", "64qam"), (0, 1), (1, 5, 10)):
        add(case("B2", f"{bw}_{mod}_{'soft' if soft else 'hard'}_{top}pct", "characterize", "quick", bandwidth_hz=bw, modulation=mod,
                 soft_clip=soft, notes=[f"Calibrate threshold at top {top}% of clean waveform amplitude distribution."],
                 clipping_percent=top))
    for bw, ripple, mod in product(PROFILES, (0.5, 1, 2), ("qpsk", "16qam", "64qam")):
        add(case("B3", f"{bw}_{mod}_{ripple}ms", "characterize", "quick", bandwidth_hz=bw, modulation=mod,
                 filter_bandwidth_hz=bw, group_delay_ripple_ms=ripple,
                 notes=["Single-carrier modem: no edge subcarriers or frequency-indexed edge symbols. Report total BER."]))
    for event in ("jitter", "underrun", "overrun"):
        add(case("B4", event, "assert", "quick", mode="messages", fec="1/2", chunk_samples=48,
                 bandwidth_hz=10000,
                 jitter_ms=2 if event=="jitter" else 0, audio_event="" if event=="jitter" else event,
                 checks=("audio_gap_reported", "no_corrupt_messages")))
    for bw, mod in product(PROFILES, ("qpsk", "16qam", "64qam")):
        add(case("B5", f"{bw}_{mod}_null", "assert", "quick", bandwidth_hz=bw, modulation=mod,
                 mode="messages", fec="1/2", chunk_samples=48, duration_s=12,
                 host_timing=1,auction_intake=1,
                 checks=("latency_2_1ms",),
                 notes=["Includes initial acquisition and audio-block residence; modeled sample-clock latency is a lower bound on software latency."]))
    add(case("C1", "ber_tables", "characterize", "full", mode="analysis",
             notes=["Aggregate A1. Report BER targets as censored when comparisons are insufficient; no interpolation across unmeasured points."]))
    add(case("C1", "standard_comparison", "assert", "full", mode="capability",
             unavailable="Current waveform has different framing, FEC/interleaving and rate map; no comparable MIL-STD conformance assertion.",
             notes=["Appendix D Tables D-I/D-II omit 10 kHz; standard waveform IDs are not implemented."]))
    for bw,snr in product(PROFILES,(0, 3, 6, 10)):
        add(case("C2", f"{bw}_acquire_{snr}dB", "assert", "quick", bandwidth_hz=bw, snr_db=snr,
                 checks=("acquired",), thresholds=("C2.acquisition_seconds",)))
    add(case("C2", "noise_10min", "assert", "quick", duration_s=600, pure_noise=1, snr_db=0,
             checks=("zero_false_acquisitions",)))
    for bw in PROFILES:
        add(case("C2", f"{bw}_cw_preamble", "assert", "quick", bandwidth_hz=bw, cw_hz=0, cw_sir_db=0,
                 checks=("acquired",), thresholds=("C2.acquisition_seconds",)))
    for bw,sign in product(PROFILES,(-1, 1)):
        add(case("C3", f"{bw}_sample_{sign}", "assert", "quick", bandwidth_hz=bw, sample_slip=sign,
                 mode="messages",fec="1/2",chunk_samples=48,
                 sample_slip_index=24000+SEED%1000, checks=("correct_message_lengths",), thresholds=("C3.recovery_frames",)))
    for mode in ("bit_insert", "bit_delete"):
        add(case("C3", mode, "assert", "quick", mode="semantics", semantics=mode,
                 checks=("correct_message_lengths",), thresholds=("C3.recovery_frames",)))
    for bw, mod, pattern_name in product(PROFILES, ("qpsk", "16qam", "64qam"), ("zeros", "ones", "alternating", "repeating", "random")):
        add(case("C4", f"{bw}_{mod}_{pattern_name}", "assert", "quick", bandwidth_hz=bw, modulation=mod, pattern=pattern_name,
                 fec="1/2", snr_db=30, thresholds=("C4.pattern_ber_margin",)))
    add(case("C4", "generated_messages", "assert", "quick", mode="semantics", semantics="patterns",
             checks=("all_messages_delivered", "correct_message_lengths"),
             notes=["256 seeded variable-length messages, 2–1024 bytes; delimiter-safe payload grammar. No declared maximum message length exists."]))
    add(case("C4", "empty_maximum_frames", "assert", "quick", mode="capability",
             unavailable="Empty RF frames are invalid; message stream has no declared maximum frame/message length. Adam must define the boundary."))
    add(case("C5", "mode_change", "assert", "quick", mode="capability",
             unavailable="No mid-stream rate/interleaver change: matched parameters change by out-of-band epoch restart; interleaver absent."))
    for overload in (1.5, 3, 10):
        add(case("D1", f"overload_{overload}", "assert", "full", mode="scheduler", duration_s=60,
                 overload=overload, checks=("no_superseded_transmissions", "bounded_scheduler_queue"), thresholds=("D1.newest_latency_ms",)))
    for survival in (0.3, 0.5, 0.8):
        add(case("D2", f"survival_{survival}", "characterize", "full", mode="paired_survival", duration_s=60,
                 target_survival=survival,survival_calibration_presets=["mid_lat_moderate","ccir_good"],
                 survival_snr_grid_db=list(SNR_GRID),survival_refinement_rounds=8,
                 notes=["Preserve both declared SNR grids, then refine measured crossing brackets; never rescale receiver outcomes to match a target."]))
        add(case("D2", f"freshness_agreement_{survival}", "assert", "full", mode="analysis",
                 target_survival=survival, thresholds=("D2.freshness_agreement_ms","D2.target_survival_margin")))
    for flood in (0, 1):
        add(case("D3", f"auction_{'flood' if flood else 'contention'}", "assert", "quick", mode="scheduler",
                 duration_s=600, overload=10, flood=flood, checks=("no_starvation", "no_priority_inversion"), thresholds=("D3.instrument_delay_ms",)))
    for semantics in ("duplicate", "out_of_order", "wrap", "fec_failure"):
        add(case("D4", semantics, "assert", "quick", mode="semantics", semantics=semantics,
                 checks={"duplicate":("no_duplicates",), "out_of_order":("no_stale_messages",),
                         "wrap":("sequence_wrap_supported",), "fec_failure":("fec_gap_reported",)}[semantics]))
    add(case("D5", "dual_path", "assert", "quick", mode="capability",
             unavailable="Fiber is the configuration/control path; no parallel fiber data-delivery arbiter exists."))
    add(case("D6", "crypto_errors_replay_restart", "assert", "full", mode="crypto",
             checks=("authenticated_delivery", "no_nonce_reuse", "replays_rejected")))
    add(case("D6", "key_rotation", "assert", "full", mode="crypto", checks=("rotation_supported",), thresholds=("D6.rotation_loss_frames",)))
    for model in ("null", "watterson", "composed"):
        kwargs=preset("high_lat_moderate") if model!="null" else {}
        if model=="composed":kwargs|=dict(clock_ppm=50,impulse_ms=1,impulses_per_second=10,impulse_above_noise_db=20,agc_step_db=20)
        add(case("E1", model, "assert", "quick", mode="determinism", snr_db=20, checks=("identical_json", "chunk_invariant"), **kwargs))
    for name in PRESETS:
        add(case("E2", name, "characterize", "full", mode="messages", fec="1/2", chunk_samples=48,
                 **preset(name), snr_db=30, duration_s=60,
                 notes=["STAC detailed audit attachment requires login. Lock uptime and a local one-second delivery-window proxy are reported; exact STAC metrics remain null."]))
    add(case("E3", "high_lat_moderate_4h", "assert", "soak", mode="soak", **preset("high_lat_moderate"),
             duration_s=14400, fec="1/2", snr_db=30, chunk_samples=48,
             checks=("no_counter_drift",), thresholds=("E3.memory_growth_bytes", "E3.queue_depth", "E3.latency_change")))
    add(case("E4", "recorded_noise", "characterize", "full", mode="recording",
             unavailable="Awaiting receive-only recordings and provenance manifest; no synthetic substitute is labeled a recording."))
    return cases


def full_parameters(c, revision, source_digest):
    p=c.parameters.copy()
    bits=BITS[p["modulation"]]
    symbol_rate=p["bandwidth_hz"]/1.25
    p |= dict(stage_order=list(STAGE_ORDER), interleaver="none (not implemented)",
              measurement_layer={"rf":"RF symbols and optional post-Viterbi source bits", "messages":"production message pipeline",
                                 "scheduler":"auction submit to simulated transmitter service; downstream unmeasured",
                                 "semantics":"production framer/deframer API", "crypto":"production crypto API"}.get(p["mode"],p["mode"]),
              waveform="Goblin Cannon single-carrier RRC; not a certified Appendix D waveform",
              symbol_rate_hz=symbol_rate, raw_bit_rate_bps=symbol_rate*bits,
              snr_definition="nominal unit-mean-constellation complex-sample signal/noise power before fading; not 3 kHz SNR or Eb/N0",
              doppler_definition="2*sigma of Gaussian power spectrum; zero path carrier shifts",
              path_gains_db=[p["path0_db"],p["path1_db"]],
              stage_seeds=dict(gaussian_noise=p["seed"],impulses=p["seed"]^0x192734AF,
                               rayleigh_path0=p["seed"]^0x638AD923,rayleigh_path1=p["seed"]^0xC94F216B,
                               payload=p["seed"]^0xC011AB1E,interferer=p["seed"]^0xE294183B),
              path_power_normalization="sum of mean path powers = 1", seed_policy="mt19937 Box-Muller; independent XOR-derived stage seeds; counter-based payload",
              rrc_rolloff=0.25, shaping_span_symbols=8, tx_gain=0.65,
              constellation_profile="mil_std_188_110c_wbhf", receiver_oversampling=1,
              pilot_sequence=[0, (1<<bits)-1], pilot_interval_symbols=32,
              header_repetition=3, acquisition_symbols=64, acquisition_seed=0xA5A50001,
              training_seed=0x5A5A0002, equalizer=dict(enabled=True, feedforward_taps=3, feedback_taps=4),
              thresholds=dict(acquisition=0.25,pilot=0.08,symbol=0.08),
              acquisition_sidelobe_guard_samples=48, frame_counter_start=7000,
              scheduler_transmit_ring_capacity=8, scheduler_log_ring_capacity=64,
              message_input_ring_capacity=1024, message_output_ring_capacity=1024,
              sample_clock_resampler="linear fractional interpolation", audio_filter="129-tap Hamming-window FIR + two first-order edge allpasses",
              gaussian_fading_filter="129 taps at 32*spread Hz; stationary initialized history; linear audio interpolation",
              agc_envelope="linear dB attack to requested step; 50 ms hold; linear dB decay to baseline",
              impulse_arrivals="periodic at declared rate; Gaussian burst RMS relative to Gaussian floor",
              crypto="AES-128-CTR, fixed test key/counter, no AEAD", sync_timestamp_enabled=False,
              aes_key_generation="16 low bytes of seeded counter pattern" if p["mode"]=="crypto" else "16 zero bytes (test fixture only)",
              aes_initial_counter_hex="00"*16, convolutional_constraint_length=7,
              convolutional_generators_octal=["171","133"], decoded_bit_confidence_threshold=0.20,
              git_commit=revision, source_tree_sha256=source_digest,
              source_revision_note="git_commit is the base revision; source_tree_sha256 identifies the tested working-tree snapshot",
              modeled_propagation_delay_s=0, execution="simulated channel")
    return p
