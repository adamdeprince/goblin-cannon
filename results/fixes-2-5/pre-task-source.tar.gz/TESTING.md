# Goblin Cannon simulated channel tests

These tests exercise the production C++ library in simulation. No result is a
radio-equipment measurement. The original audit preserved production behavior;
Adam subsequently authorized the 24 kHz header fix. Follow-up results retain
their own source hashes and are stored separately from the original audit.
See the [24 kHz fix validation](results/24khz-header-fix/FIX.md) for the latest
clean-profile results and the remaining defects.

## Build the simulated channel harness

```sh
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release \
  -DGOBLIN_CANNON_TEST_REQUIRE_AVX512=ON
cmake --build build -j 4
```

Use an x86-64 host; `avx10` provides AVX-512 validation and `naamah` provides
the quiet-host AVX2 latency comparison. Required packages
on Ubuntu are CMake, Ninja, a C++23 compiler, `libgrpc++-dev`,
`protobuf-compiler-grpc`, `protobuf-compiler`, `libprotobuf-dev`, `libssl-dev`,
and Python 3.11+. The matrix runner uses only Python's standard library.

## Run a simulated channel tier

```sh
python3 tests/simulated_channel/run.py --tier quick --jobs 4
python3 tests/simulated_channel/run.py --tier full --jobs 4
# Manual only: this preserves one continuous, paced four-hour stream.
python3 tests/simulated_channel/run.py --tier soak --jobs 1
```

Every matrix case has exactly one `quick`, `full`, or `soak` tier and one
`assert` or `characterize` kind. Select a group with `--group A4`; select a case
with `--case NAME`; inspect the complete parameter manifest with `--list`.
`--probe PATH`, `--results PATH`, and `--seed INTEGER` are explicit overrides.
AVX-512 dispatch is required unless `--allow-non-avx512` is supplied and recorded.

Tier budgets are 120 seconds, 1,800 seconds, and 4–12 hours. Long quick cases
still process every sample in their specified ten-minute simulated duration.
The runner reports budget overruns; it never reduces a duration or grid.
A1 uses **10 simulated seconds per point**, all ten supported constellations,
three implemented FEC rates, both bandwidths, all nine presets, and 0–30 dB SNR
in 2 dB steps. These are screening curves. They do not establish F.1487's much
longer statistical-duration operating limits; C1 marks such limits unestablished.

When using a source copy without `.git`, pass `--git-commit COMMIT` and
`--source-digest SHA256` from the originating workspace. Obtain the latter with:

```sh
PYTHONPATH=tests/simulated_channel python3 -c 'from run import source_digest; print(source_digest())'
```

## Run a quiet-host simulated channel latency check

On `naamah`, configure with `-DGOBLIN_CANNON_TEST_REQUIRE_AVX512=OFF`; its
Threadripper PRO 5995WX supports AVX2. After building and running CTest, run B5
with one worker so validation jobs do not compete during wall-clock measurement:

```sh
python3 tests/simulated_channel/run.py --tier quick --group B5 --jobs 1 \
  --allow-non-avx512 --results results/latency-retest
```

Supply the revision/source-digest arguments above when using a source copy.
Use a separate output directory for each repetition to retain host observations.
The [naamah comparison](results/naamah/COMPARISON.md) preserves three serial
repetitions, full parameters, host metadata, stage timings and the original
`avx10` baseline. Startup remains included in the 2.1 ms assertion.

## Read simulated channel results

- `results/<test_name>/<seed>.json`: full configuration, revision/source hash,
  observations, metric definitions, assertions, and open thresholds.
- `results/SUMMARY.md`: group tables, every expected failure, open thresholds,
  and limitations. Group CSVs retain the full parameters and metrics for plotting.
- `results/EXECUTION.json`: **non-canonical** host runtime observations. These
  vary with scheduling and are not included in seeded byte-equality checks.
  `EXECUTION-quick.json` and `EXECUTION-full.json` preserve complete tier timings;
  selected reruns have separate files and cannot erase a budget overrun.
- Soak `.host.json` files similarly hold non-canonical resident-memory samples
  with the full test parameters. Per-hour deterministic latency/counter metrics
  remain in the canonical result. The soak bounds are still `THRESHOLD_TBD`.
- B5 `.host.json` files hold measured source-to-sink wall latency and stage call
  timings, including the real auction, TX/RX framing/FEC/crypto/modem and paced
  simulated audio buffering. OS scheduling is included. Stage durations are per
  call, not an additive decomposition of each message's latency. No physical
  audio device or network socket is represented by this loopback.

`characterize` never gates on a BER target. Assertions use only stated brief
requirements; missing margins stay `THRESHOLD_TBD`, as confirmed by Adam.
Measurements and proposed values remain available for later review; proposed
values are not enforced. Reviewed production defects
are listed by exact case/assertion in `expected_failures.json`; tests still run.
A new failure, harness error, or unexpected pass fails the runner. Unsupported
conditional features and missing inputs are `unavailable`, never passes.

As confirmed by Adam, the new matrix disables the existing combined
carrier/phase correction switch.
The equalizer remains enabled with three feedforward and four feedback taps.
Findings apply to that declared configuration.
BER is conditional on observed bits; missing bits
and frames are reported separately. Frame survival includes missing frames.
Message latency uses creation-to-delivery sample-clock time including startup
and audio buffering. B5 additionally reports non-canonical host measurements.
Exact STAC comparability is not claimed. See the [audit questions](tests/simulated_channel/QUESTIONS.md).

`acquisition_time_s` follows the existing receiver's `acquisition_found` event:
first preamble detection. A valid header is separately required by C2's assertion;
detecting a preamble alone does not pass that test. `reacquisition_time_s` uses the
first validated header after signal return. Acquisition deadlines remain open.

D1 keeps the isolated auction test and also runs a null-channel overload stream
through the actual auction, framer, FEC, crypto, modem and sink. The latter offers
wire bytes (including CRC) at each multiple of the declared steady payload bit
rate. Results retain newest-only per-key latency and ten chronological windows.
D3's contention and flood checks isolate the auction so RF acquisition does not
hide starvation. No source-side coalescer or receiver deduplicator is added.
D2 preserves 0–30 dB grids on `mid_lat_moderate` and `ccir_good`, then performs
eight refinements of observed SNR crossing brackets. Every trial lasts 60
simulated seconds. Requested and measured survival fractions are kept separate.

## Extend the simulated channel

`tests/channel_simulator.hpp` is the single simulator shared with the original
regression tests. Its order is channel → interferers → impulsive noise → dropout
→ AGC → clipping → band-limiting → sample-clock mismatch → residual offset/drift
→ audio delivery jitter. Each stage is controlled by explicit parameters.

Add a stage's configuration/state to that header, parse it in the test-only C++
probe, and add its defaults and metadata to `catalog.py`. Keep state and PRNG
draws independent of input chunk boundaries. Extend E1's repeated/chunked checks.
Declare its location in the order; do not add a second independent simulator.

For a test, add a `Case` to `catalog.py` with its kind, tier, parameters, and a
stated assertion or characterization. Put new open margins in `OPEN_THRESHOLDS`.
The test-only adapters call public production APIs; do not add receiver fixes or
replacement scheduler/crypto logic to make a requirement pass.

## Recorded-noise simulated channel cases

E4 is unavailable until recordings are supplied. `--recordings manifest.json`
accepts a list of entries with `path`, `sha256`, `sample_rate_hz`, `format`,
`frequency_hz`, `utc`, `receiver_location`, `source_url`, and `permission`.
The supported format is `fc32_iq_le` at 48 ksample/s. Conversion must be explicit
and documented; the runner never loops a short capture or fabricates provenance.

## Other simulated channel checks

```sh
python3 -m unittest discover -s tests/simulated_channel -p 'test_*.py'
ctest --test-dir build --output-on-failure
```

For CI, configure `-DGOBLIN_CANNON_RUN_SIMULATED_CHANNEL_QUICK=ON`, then run
`ctest --test-dir build -L quick --output-on-failure`. This includes the complete
matrix, original regressions, and Python harness checks. Source copies without
`.git` also need `-DGOBLIN_CANNON_TEST_GIT_COMMIT=COMMIT`. The current `avx10`
quick matrix exceeds the requested two-minute budget; enabling CI does not hide
that finding. It remains an explicit, opt-in CTest entry while that is unresolved.

The older ten CTest entries remain regression checks for their original
configuration, including carrier correction enabled. Their pass does not satisfy
the new brief's radio/software boundary; the new matrix records that distinction.
